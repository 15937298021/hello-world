package tv;

public class HisenseTv extends Tv{
	public void play(){
		System.out.println("This is HisenseTv.");
	}
}
