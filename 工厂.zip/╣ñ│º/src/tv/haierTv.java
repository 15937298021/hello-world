package tv;

public class haierTv extends Tv{
public void play(){
	System.out.println("This is HaierTv.");
}
}