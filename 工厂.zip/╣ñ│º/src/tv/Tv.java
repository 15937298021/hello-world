package tv;

public abstract class Tv{
	public abstract void play();
}
