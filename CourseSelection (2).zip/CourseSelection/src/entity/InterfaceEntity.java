package entity;//ʵ���

public interface InterfaceEntity {
	
}
